package homepage;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.google.common.io.Files;
public class HomePage {
	public static WebDriver driver;
	public XSSFWorkbook wb;     //WorkBook
	public static Properties prop;
	//Method for loading properties file
	public void loadproperties() {
		try {
			prop = new Properties();
			InputStream in = new FileInputStream(System.getProperty("user.dir")+"\\src\\test\\resources\\ObjectRepository\\config.properties");
			prop.load(in); //Reading File data
		} catch (Exception e) {
		}
	}
	//browser setup method
	public void setup(String browser, String url) {
		String path = System.getProperty("user.dir");
		if (browser.equalsIgnoreCase("chrome")) {
			System.setProperty("webdriver.chrome.driver", path+"\\src\\test\\resources\\Drivers\\chromedriver.exe");
			ChromeOptions options = new ChromeOptions();
			options.addArguments("--disable-notifications");  //Disable any notifications
			options.addArguments("--disable-blink-features=AutomationControlled");
			driver = new ChromeDriver(options);
		}
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS); // wait for 20 seconds of time before throwing an exception
		driver.get(url); 
		driver.manage().window().maximize(); //maximize the window
	}
	//Reporting methods
	public void visibilitywaitwithclick(String xpath, int seconds) {
		WebDriverWait wait = new WebDriverWait(driver, seconds); //Method to wait until webElement was found
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(xpath))));
		driver.findElement(By.xpath(xpath)).click();  //Then click it
	}
	public void Thread(int seconds) {
		try {
			Thread.sleep(seconds * 1000);    //Used to stop execution of current thread
		} catch (Exception e) {
		}
	}
    //Data Providing method 
	public Object[][] data(String fileName) throws Exception {
		FileInputStream fis = new FileInputStream(System.getProperty("user.dir")+"\\src\\test\\resources\\ExcelFiles\\Testdata.xlsx");
		wb = new XSSFWorkbook(fis); //WorkSheet
		XSSFSheet sh = wb.getSheetAt(0); //1st Sheet of workBook
		int rows = sh.getPhysicalNumberOfRows(); //Number of rows
		int cols = sh.getRow(0).getPhysicalNumberOfCells(); //Number of columns
		Object arrayObj[][] = new Object[rows - 1][cols];
		for (int i = 1; i < rows; i++) {
			for (int j = 0; j < cols; j++) {
				arrayObj[i - 1][j] = getData(0, i, j); // Refers to getData method 
			}
		}
		fis.close();
		wb.close();
		return arrayObj;
	}
	//Retrieving data from excel file
	public String getData(int sheetNumber, int row, int column) {
		XSSFSheet sheet = wb.getSheetAt(sheetNumber); //To get sheet in workbook
		DataFormatter df = new DataFormatter();
		String data = df.formatCellValue(sheet.getRow(row).getCell(column)); //Pass data in current sheet of the workbook
		return data;
	}
	//To take a Screenshot
	public void ScreenShot(String filename) throws IOException {
		TakesScreenshot ss=(TakesScreenshot) driver;   // create an object to capture and store a screenshot
		File src=ss.getScreenshotAs(OutputType.FILE);   //Source file
		File dest=new File(System.getProperty("user.dir")+"\\src\\test\\java\\screenshotcaptures\\screenshot"+filename+".png");
		Files.copy(src, dest);
	}
}