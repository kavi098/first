package testcases;
import java.io.IOException;
import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import homepage.FreelistingPage;
import homepage.HomePage;
public class FreeListingTestCases extends HomePage {
	public ExtentReports report;
	public FreelistingPage obj;
	//Browser calling and Report Generation

	public void browser() {
		loadproperties();
		setup(prop.getProperty("browser"), prop.getProperty("baseUrl"));
		ExtentHtmlReporter Reporter1 = new ExtentHtmlReporter(".\\HTMLReports\\"+"FreeListingPageExtentReport.html");
		report = new ExtentReports(); //To build the report
		report.attachReporter(Reporter1);
		obj = new FreelistingPage(); 
	}
	//Method for Launching FreeListing Page
	@Test(priority = 1, groups="Regression Test")
	public void launch(){
		browser();
		ExtentTest test1 = report.createTest("Free Listing Page Launching","Testing title of Free Listing Page");
		driver.findElement(By.xpath("//*[@id='city']")).clear();
		Thread(2);
		driver.findElement(By.xpath("//*[@id='city']")).sendKeys(prop.getProperty("location"));
		Thread(3);
		visibilitywaitwithclick("//ul[@id='cuto']/li", 100);
		visibilitywaitwithclick("//li[@class='button-top']", 100);
		test1.info("Free Listing is opening");
		Thread(3);
		Assert.assertEquals(driver.getTitle(), "Free Listing - Just Dial - List In Your Business For Free");
		test1.pass("Test case is Passed");
	}
	//This Method Enter all fields as Null in FreeListing Page
    @Test(priority=2, groups="Regression Test")
    public void allNullValues() throws IOException {
    	obj.elements();
    	ExtentTest test2 = report.createTest("All NullValues","Testing Freelisting Page with all Null values");
    	obj.cityName.clear();
    	obj.submit.click();
    	ScreenShot("AllNullValues"); //Takes a screenshot after click of submit button
    	test2.info("All fields are null");
    	Thread(2);
    	String alert = driver.findElement(By.xpath("//span[@class='almsg']")).getText();
		Assert.assertEquals("City is blank", alert);
		test2.pass("Test case Is Passed");
		driver.navigate().refresh();
    }
    //This Method Keeps Company field as Null 
	@Test(priority = 3, dataProvider = "testData", groups="Regression Test")
	public void companyNullValue(String company, String fname, String lname, String mobile, String land){
		obj.elements();
		ExtentTest test3 = report.createTest("Company NullValue","Testing Company Null Value Validation Of The Freelisting Page");
		obj.firstName.sendKeys(fname);
		obj.lastName.sendKeys(lname);
		obj.mobileNumber.sendKeys(mobile);
		obj.landLine.sendKeys(land);
		obj.submit.click();
		Thread(2);
		String errormessage=driver.findElement(By.xpath("//*[@id='fcoe']")).getText();
		System.out.println("Error message without entering Company name: "+errormessage); //Display error in console
		test3.info("The Form values Are Entered With Company Value As Null");
		String alert = driver.findElement(By.xpath("//span[@class='almsg']")).getText(); //Get text of this web element
		test3.info("The Error Message Is Shown In The Window");
		Assert.assertEquals("Company name is blank", alert);
		test3.pass("Test case Is Passed");
		driver.navigate().refresh();
	}
	//This Method keeps Mobile field as Null
	@Test(priority = 4, dataProvider = "testData", groups="Regression Test")
	public void mobileNullValue(String company, String fname, String lname, String mobile, String land) throws IOException{
		obj.elements();
		ExtentTest test4 = report.createTest("MobileNumber Nullvalue","Testing MobileNumber Null Value Validation Of The FreelistingPage");
		obj.companyName.sendKeys(company);
		obj.firstName.sendKeys(fname);
		obj.lastName.sendKeys(lname); //Mobile field as null
		test4.info("The Form values Are Entered With MobileNumber As Null");
		obj.submit.click();
		test4.info("The Alert Is Displayed");
		String text = driver.switchTo().alert().getText(); //Get text in the alert box
		System.out.println("Error message without entering mobile number: "+text);
		driver.switchTo().alert().accept(); //driver will switch to alert window and accepts that alert
		Assert.assertEquals("Please enter mobile number or landline number", text);
		test4.pass("Test case Is Passed");
		driver.navigate().refresh();
	}
	//This method keeps City field as Null
	@Test(priority = 5, dataProvider = "testData", groups="Regression Test")
	public void cityNullvalue(String company, String fname, String lname, String mobile, String land){
		obj.elements();
		ExtentTest test5 = report.createTest("City Nullvalue","Testing City Null Value Validation Of The FreelistingPage");
		obj.companyName.sendKeys(company);
		obj.cityName.clear();   //Only leave city field empty
		obj.firstName.sendKeys(fname);
		obj.lastName.sendKeys(lname);
		test5.info("The Form values Are Entered With City As Null");
		obj.submit.click();
		String citynameerror=driver.findElement(By.xpath("//*[@id=\"fcoe\"]")).getText();
		System.out.println("Error message without entering city name: "+citynameerror); //prints on the console
		Thread(3);
		test5.info("The Error Message Is Shown In The Window");
		String alert = driver.findElement(By.xpath("//span[@class='almsg']")).getText(); //Get text from an alert box
		Assert.assertEquals("City is blank", alert);
		test5.pass("Test case Is Passed");
		driver.navigate().refresh(); //To refresh the current window
	}
	//This method Enter all fields with valid data
	@Test(priority = 6, dataProvider = "testData", groups="Regression Test")
	public void validDataTest(String company, String fname, String lname, String mobile, String land) {
		obj.elements();
		ExtentTest test6 = report.createTest("Valid Data","Validation Of The FreelistingPage with valid data"); //To generate test with description
		obj.companyName.sendKeys(company); //These data will get by excel sheet
		obj.firstName.sendKeys(fname);
		obj.lastName.sendKeys(lname); //Enter valid data of all fields
		obj.mobileNumber.sendKeys(mobile);
		obj.landLine.sendKeys(land);
		obj.submit.click();	
		Thread(2);
		test6.info("The Form values Are Entered With all valid details");
		String actual=driver.getTitle(); //Get title of the current page url
		String expected="Free Listing Business Info";
		Assert.assertEquals(actual, expected); //Compare two strings and provide result accordingly
		test6.pass("Successfully registered and case is passed");	
		driver.navigate().back(); // Navigates to previous page
		terminate();
	}
	//Data Provider to all the used methods
	@DataProvider
	public Object[][] testData() throws Exception {
		return data("Testdata.xlsx");
	}
	//Method for closing Browser
	public void terminate() {
		driver.close(); 
		report.flush();
	}
}