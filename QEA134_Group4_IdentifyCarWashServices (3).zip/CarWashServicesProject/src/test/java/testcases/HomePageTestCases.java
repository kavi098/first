package testcases;
import java.io.IOException;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import homepage.HomePage;
public class HomePageTestCases extends HomePage {
	public ExtentReports report;
	// Browser Calling and Report Generation
	
	public void browser() {
		loadproperties();
		setup(prop.getProperty("browser"), prop.getProperty("baseUrl"));
		ExtentHtmlReporter Reporter1 = new ExtentHtmlReporter(".\\HTMLReports\\HomepageExtentReport.html");
		report = new ExtentReports();
		report.attachReporter(Reporter1);
	}
	// Method to check whether WebSite is Opening or not
	@Test(priority = 1, groups="Smoke Test")
	public void websiteTest() {
		browser(); // call for the brower method and extent reports
		ExtentTest test = report.createTest("Website validation", "Test for checking website Functioning");
		String actual = driver.getTitle();
		String expected = "Justdial - Local Search, Social, News, Videos, Shopping";
		Assert.assertEquals(actual, expected);
		test.pass("Website is opened");
	}
	@Test(priority=2, dependsOnMethods="websiteTest", groups="Smoke Test")
	public void customercaretest() {
		ExtentTest test=report.createTest("Validating Customer care ","Test for checking customer care is accessable");
		driver.findElement(By.xpath("/html/body/div[10]/a[2]")).click();
		Thread(2);
		String actual=driver.getTitle(); // Get title of current window
		String expected="Justdial Customer Support - Customer Care for Clients";
		Assert.assertEquals(actual, expected);
		driver.navigate().back(); //Go to previous window
		test.pass("Customer care serives are available");
		}
	// Method to check The Presence of Elements in justdial.com
	@Test(priority = 3, groups="Smoke Test")
	public void elementsTest() {
		ExtentTest test = report.createTest("Validating Elements in homepage","Test for checking City,Search and Search box elements");
		Assert.assertTrue(driver.findElement(By.xpath("//*[@id=\"city\"]")).isDisplayed()); //Check the presence of the elements 
		test.info("City box is Present");
		Assert.assertTrue(driver.findElement(By.xpath("//*[@id=\"srchbx\"]")).isDisplayed());
		test.info("Search box is Present");
		Assert.assertTrue(driver.findElement(By.xpath("//*[@id=\"srIconwpr\"]")).isDisplayed());
		test.info("Search button is Present");
		test.pass("All required elements are present and case is passed");
	}
	// This Method is used to Check Login Pop-up
	@Test(priority = 4, groups="Smoke Test")
	public void loginPageTest() {
		ExtentTest test = report.createTest("Login page validation", "Test for checking login popup");
		driver.findElement(By.id("h_login")).click();
		test.info("login is clicked");
		Assert.assertTrue(driver.findElement(By.xpath("//div[@class='modal-header']")).isDisplayed()); // Checks for text is displayed or not
		driver.navigate().refresh(); // refresh the current window
		test.pass("login popup is displayed and case is passed");
	}
	// This Method is used To check Location
	@Test(priority = 5, groups="Smoke Test")
	public void locationTest() {
		ExtentTest test = report.createTest("Validating Location","Test for checking whether location can be changeable or not");
		Thread(1);
		driver.findElement(By.xpath("//*[@id=\"city\"]")).clear(); // Clear text in that field 
		test.info("City box is clicked");
		driver.findElement(By.xpath("//*[@id=\"city\"]")).sendKeys(prop.getProperty("location"));
		driver.findElement(By.xpath("//ul[@id='cuto']/li")).click(); // Display the drop down suggestion then select it by click
		test.info(prop.getProperty("location") + " Location is entered");
		String expected = prop.getProperty("location");
		driver.navigate().refresh();
		String actual = driver.findElement(By.xpath("//*[@id='city']")).getAttribute("placeholder");
		Assert.assertEquals(actual, expected);
		test.pass("Location is as expected and case is passed");
	}
	// This method is used to Enter all search details
	@Test(priority = 6, dependsOnMethods = "locationTest", groups="Smoke Test")
	public void searchingTest() {
		ExtentTest test = report.createTest("Entering Search details", "Test for entering details related to search");
		Thread(1);
		driver.findElement(By.xpath("//*[@id=\"srchbx\"]")).sendKeys(prop.getProperty("service"));
		test.info(prop.getProperty("service") + " is entered in searchbox"); //Select service from config file
		driver.findElement(By.xpath("//*[@id='srIconwpr']")).click();
		test.info("search button is clicked");
		Assert.assertTrue(true);
		test.pass("All entered details are taken and case is passes");
	}
	// This method is used to check Result page
	@Test(priority = 7, dependsOnMethods = "searchingTest", groups="Smoke Test")
	public void resultPageTest() {
		ExtentTest test = report.createTest("Result Page Validation", "Test To Validate The Title of SearchResultPage");
		String actual = driver.findElement(By.tagName("h1")).getText();
		String expected = prop.getProperty("service") + " in " + prop.getProperty("location"); //Get location from properties file
		Assert.assertEquals(actual, expected);
		test.pass("Result page is as expected and case is passed");
	}
	// This Method is used to check Best deals Pop-up
	@Test(priority = 8, dependsOnMethods = "resultPageTest", groups="Smoke Test")
	public void bestdealsTest() {
		ExtentTest test = report.createTest("validating BestDeals Popup", "Test to check Bestdeals in ResultPage");
		driver.findElement(By.xpath("//ul[@class='brdUL']//li[7]")).click();
		test.info("Bestdeals button is clicked");
		Thread(2); //Sleep method
		String text = driver.findElement(By.xpath("//*[@id='best_deal_div']//section/" + "span[@class='jbt']")).getText();
		Assert.assertTrue(text.contains(prop.getProperty("service")));
		test.info("Best Deals Popup Is Displayed");
		Thread(1);
		driver.findElement(By.xpath("//*[@id=\"best_deal_div\"]/section/span")).click();
		test.pass("Best Deals Filter Test Case Is Passed");
	}
	// This Method is used to check Votes and Rating
	@Test(priority = 9, dependsOnMethods = "bestdealsTest", groups="Smoke Test")
	public void ratingCheck() {
		ExtentTest test = report.createTest("Validating Stars and Votes","Test for checking the presence of stars and votes");
		Boolean rating = driver.findElement(By.xpath("//ul[contains(@class,'padding')]//child::li//"+ "p[contains(@class,'new')]//span[contains(@class,'green')]")).isDisplayed();
		Boolean votes = driver.findElement(By.xpath("//ul[contains(@class,'padding')]//child::li//"+ "p[contains(@class,'new')]//span[contains(@class,'vote')]")).isDisplayed();
		
		Assert.assertTrue(rating);
		test.info("Ratings are present"); 
		Assert.assertTrue(votes); //Evaluate the condition
		test.info("Votes are present");
		test.pass("Stars,Votes are validated and Case is passed");
	}
	// This method is used to print data
	@Test(priority = 10, dependsOnMethods = "ratingCheck", groups="Smoke Test")  //Depends on ratingCheck method 
	public void printData() throws IOException {
		ExtentTest test = report.createTest("Validating Print data", "Test to display top 5 Car Wash Services");
		driver.findElement(By.xpath("//*[@id=\"distdrop_rat\"]")).click();
		Thread(2); //Thread.sleep Wait method
		ScreenShot("CarServices");
		List<WebElement> shop = driver.findElements(By.xpath("//ul[contains(@class,'padding')]//" + "child::li//h2"));
		List<WebElement> star = driver.findElements(By.xpath("//ul[contains(@class,'padding')]//child::"+"li//p[contains(@class,'new')]//span[contains(@class,'green')]"));
		List<WebElement> votes = driver.findElements(By.xpath("//ul[contains(@class,'padding')]//child::"+"li//p[contains(@class,'new')]//span[contains(@class,'vote')]"));
		System.out.println("------------------------------------------------------");
		System.out.println("Top 5 Car Wash Services");
		int totalpassed = 0;
		for (int i = 0; i < star.size(); i++) {
			float ratings = Float.parseFloat(star.get(i).getText());
			String numeric[] = votes.get(i).getText().split(" "); 
			int vote = Integer.parseInt(numeric[0]);
			if (totalpassed < 5) {
				if (ratings > 4 && vote > 20) {
					System.out.println(   
							i + 1 + ". " + shop.get(i).getText() + "|| " + ratings + "|| " + votes.get(i).getText());
					totalpassed++; //To display shop names, ratings and votes on console
				}
			}
		}
		System.out.println("------------------------------------------------------");
		test.pass("Top 5 Car Wash Services are displayed");
		terminate();
	}
	// Method for closing Browser
	public void terminate() {
		driver.close();
		report.flush();
	}
}