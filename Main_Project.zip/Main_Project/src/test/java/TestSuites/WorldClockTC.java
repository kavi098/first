package TestSuites;

import java.io.IOException;
import java.util.Scanner;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import Base.Base;
import Pages.WorldClock;

public class WorldClockTC extends Base {

	WorldClock ha = new WorldClock();

	// To invoke browser
	@BeforeTest
	public void invokeBrowser() {
		logger = report.createTest("Executing Test Cases");

		ha.invokeBrowser();
		reportPass("Browser is Invoked");
	}

	@Test(priority = 1)
	public void OpeningURLTest() throws InterruptedException, IOException {
		ha.openURL();
		reportPass("Opened URL successfuly");
	}

	@Test(priority = 2)
	public void loginTest() {
		// Scanner sc = new Scanner(System.in); // Input from user
		// System.out.println("Enter user email");
		// String useremail = sc.next();
		// System.out.println("Enter password");
		// String userpassword = sc.next();
		ha.login();
		reportPass("Logged in successfuly");
	}

	@Test(priority = 3)
	public void TimeTest() throws InterruptedException {
		ha.CurrentTime();
		reportPass("Printed current Time successfuly");
	}

	@Test(priority = 4)
	public void ScrollTest() throws InterruptedException {

		ha.slideBar();
		reportPass("Scrolled down successfuly");
	}

	@Test(priority = 5)
	public void TimeZoneTest() throws InterruptedException {
		ha.DiffTime();
		reportPass("Displayed different Timezones successfuly");
	}

//For closing browser
	@AfterTest
	public void closeBrowser() throws IOException {
		reportPass("Browser is closed successfuly");
		ha.endReport();
		ha.closeBrowser();
	}
}