package homepage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
public class FreelistingPage extends HomePage {
	public WebElement companyName, cityName, firstName, lastName, mobileNumber, landLine, submit;
	//Method for finding webElements in Free listing Page by id, name, xpath
	public void elements() {
		companyName = driver.findElement(By.id("fcom")); 
		cityName = driver.findElement(By.name("fcity"));
		firstName = driver.findElement(By.name("fname"));
		lastName = driver.findElement(By.name("lname"));
		mobileNumber = driver.findElement(By.name("mn[]"));
		landLine = driver.findElement(By.name("ph"));
		submit = driver.findElement(By.xpath("//button[@class='bbtn subbtn']"));
	}
}